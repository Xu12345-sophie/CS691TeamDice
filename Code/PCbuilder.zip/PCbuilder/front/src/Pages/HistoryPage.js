import React from 'react'

export default function HistoryPage(){
    return (
        <div>
          <h1>Order placed</h1>
        </div>
    )
}