import React from 'react';
import { BrowserRouter, Link, Route } from 'react-router-dom';
import CartPage from './Pages/CartPage';
import HomePage from './Pages/HomePage';
import ProductPage from './Pages/ProductPage';
import {useDispatch, useSelector} from 'react-redux';
import LoginPage from './Pages/LoginPage';
import { signout } from './actions/userAction';
import RegisterPage from './Pages/RegisterPage';
import ShippingPage from './Pages/ShippingPage';
import PlaceOrderPage from './Pages/PlaceOrderPage';
import OrderPage from './Pages/OrderPage';
import AdminRoute from './components/AdminRoute';
import ProductListPage from './Pages/ProductListPage';
import OrderListPage from './Pages/OrderListPage';
import ProfilePage from './Pages/ProfilePage';
import ProductEditPage from './Pages/ProductEditPage';
import PrivateRoute from './components/PrivateRoute.js';
import UserListPage from './Pages/UserListPage';
import UserEditPage from './Pages/UserEditPage';

/* use product component and pass property*/
/* route should be define in the main section*/
/* show login user header*/
/* add register page to the route*/
/* add shipping page to the route */
/* add admin menu and ony show it when user is admin type*/
function App() {

  const cart = useSelector(state => state.cart);
  const {cartItems} = cart;
  const userSignin = useSelector((state) => state.userSignin);
  const { userInfo } = userSignin;
  const dispatch = useDispatch();
  const signoutHandler= () =>{
    dispatch(signout());

  }
  return (
    <BrowserRouter>
    <div className="grid">
            
    <header className="row">
      <div>
        <Link className="ti" to="/">PCbuilder Completed Builds</Link>
      </div>
      <div>
  <Link to="/cart">mybuild{cartItems.length >0 && (
    <span className="badge">{cartItems.length}</span>
  )}</Link>
      {
        userInfo ? (
          <div className="dropdown">
        <Link to="#">{userInfo.name} <i className="fa fa-caret-down"></i></Link>
        <ul className="dropdown-content">
          <li>
            <Link to="/profile">User Profile</Link>
          </li>
          <Link to="#signout" onClick={signoutHandler}>Log out</Link>
        </ul>
        </div>
        ) :  (
            <Link to="/signin">Sign In</Link>
        )
      }
      
      {userInfo && userInfo.isAdmin && (
        <div className="dropdown"> 
          <Link to="#admin">Admin <i className="fa fa-caret-down"></i></Link>
          <ul className="dropdown-content">
           <li>
             <Link to="/productlist">Products</Link>
           </li>
           <li>
             <Link to="/orderlist">Order Placed</Link>
           </li>
           <li>
                    <Link to="/userlist">Users</Link>
                  </li>
          </ul> 
        </div>
      )}
      
      </div>
    </header>
  <main>
    <Route path="/product/:id" component={ProductPage} exact></Route>
    <Route path="/product/:id/edit" component={ProductEditPage} exact></Route>
    <Route path="/" component={HomePage} exact></Route>
    <Route path="/cart/:id?" component={CartPage}></Route>
    <Route path="/signin" component={LoginPage}></Route>
    <Route path="/register" component={RegisterPage}></Route>
    <Route path="/shipping" component={ShippingPage}></Route>
    <Route path="/placeorder" component={PlaceOrderPage}></Route>
    <Route path="/order/:id" component={OrderPage}></Route>
    <PrivateRoute path="/profile" component={ProfilePage}></PrivateRoute>
    <AdminRoute path="/productlist" component={ProductListPage}></AdminRoute>
    <AdminRoute path="/orderlist" component={OrderListPage}></AdminRoute>
    <AdminRoute path="/userlist" component={UserListPage}></AdminRoute>
    <AdminRoute path="/user/:id/edit" component={UserEditPage}  ></AdminRoute>
    
  </main>
  <footer className="row center"> @2020 PC builder </footer>
</div>
</BrowserRouter>
  );
}

export default App;
