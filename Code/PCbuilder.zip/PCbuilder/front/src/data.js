const data = {
    products: [
     {
         _id:'1',
         name:'NZXT build',
         category:'Shirts',
         image:'/images/p1.jpg',
         price:120,
         countInStock: 1,
         brand:'Nike',
         rating:4.0,
         numReviews:10,
         description: 'high quality product',
     },
     
    
    ],
};
export default data;