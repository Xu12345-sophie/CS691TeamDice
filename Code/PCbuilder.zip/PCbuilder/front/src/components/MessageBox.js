import React from 'react'

/* children shows info in messagebox  */
/* to show message based on variant of message if is error show red, information will be blue*/
export default function MessageBox(props) {
    return (
        <div className={`alert alert-${props.variant || 'info'}`}>
              {props.children}
        </div>    
    );
}